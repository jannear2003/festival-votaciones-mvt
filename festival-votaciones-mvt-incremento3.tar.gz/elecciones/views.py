from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import HttpResponseNotAllowed
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from .forms import CategoriaForm, CopiarCategoriasForm
from .models import Categoria, Edicion, EstadoBase, Votacion

def inicio(request):
    edicion = Edicion.objects.filter(estado=Edicion.Estado.ACTIVA).order_by("-anio").first(); votaciones = Votacion.objects.none()
    if edicion:
        votaciones = Votacion.objects.filter(categoria__edicion=edicion, categoria__estado=EstadoBase.ACTIVO, categoria__visible_publicamente=True, publicada=True).select_related("categoria", "tipo").annotate(total_opciones=Count("opciones", filter=Q(opciones__activa=True)))
    return render(request, "elecciones/inicio.html", {"edicion": edicion, "votaciones": votaciones})

def detalle(request, slug):
    votacion = get_object_or_404(Votacion.objects.select_related("categoria", "categoria__edicion", "tipo").prefetch_related("opciones"), slug=slug, publicada=True, categoria__visible_publicamente=True)
    return render(request, "elecciones/detalle.html", {"votacion": votacion})

@login_required
def panel(request):
    return render(request, "elecciones/panel.html", {"ediciones": Edicion.objects.count(), "categorias": Categoria.objects.count(), "votaciones": Votacion.objects.count(), "publicadas": Votacion.objects.filter(publicada=True).count(), "ultimas": Votacion.objects.select_related("categoria", "categoria__edicion")[:5]})

@login_required
def categorias_lista(request):
    categorias = Categoria.objects.select_related("edicion", "edicion__festival").annotate(total_votaciones=Count("votaciones")); q=request.GET.get("q","").strip(); edicion=request.GET.get("edicion","").strip(); estado=request.GET.get("estado","").strip()
    if q: categorias=categorias.filter(Q(nombre__icontains=q)|Q(descripcion__icontains=q)|Q(edicion__nombre__icontains=q))
    if edicion: categorias=categorias.filter(edicion_id=edicion)
    if estado: categorias=categorias.filter(estado=estado)
    return render(request,"elecciones/categorias_lista.html",{"categorias":categorias,"ediciones":Edicion.objects.all(),"estados":EstadoBase.choices,"filtros":{"q":q,"edicion":edicion,"estado":estado}})

@login_required
def categoria_crear(request):
    form=CategoriaForm(request.POST or None)
    if request.method=="POST" and form.is_valid():
        categoria=form.save(); messages.success(request,f"La categoría “{categoria.nombre}” fue creada correctamente."); return redirect("elecciones:categorias_lista")
    return render(request,"elecciones/categoria_form.html",{"form":form,"titulo":"Crear categoría"})

@login_required
def categoria_editar(request,pk):
    categoria=get_object_or_404(Categoria,pk=pk); form=CategoriaForm(request.POST or None,instance=categoria)
    if request.method=="POST" and form.is_valid():
        categoria=form.save(); messages.success(request,f"La categoría “{categoria.nombre}” fue actualizada."); return redirect("elecciones:categorias_lista")
    return render(request,"elecciones/categoria_form.html",{"form":form,"titulo":"Editar categoría","categoria":categoria})

@login_required
def categoria_estado(request,pk,accion):
    if request.method!="POST": return HttpResponseNotAllowed(["POST"])
    categoria=get_object_or_404(Categoria.objects.select_related("edicion"),pk=pk); destinos={"activar":EstadoBase.ACTIVO,"desactivar":EstadoBase.INACTIVO,"archivar":EstadoBase.ARCHIVADO}
    if accion not in destinos: messages.error(request,"La acción solicitada no es válida."); return redirect("elecciones:categorias_lista")
    categoria.estado=destinos[accion]
    if categoria.estado!=EstadoBase.ACTIVO: categoria.visible_publicamente=False
    try:
        categoria.full_clean(); categoria.save(update_fields=["estado","visible_publicamente","actualizado_en"]); messages.success(request,f"La categoría “{categoria.nombre}” ahora está {categoria.get_estado_display().lower()}.")
    except Exception as exc: messages.error(request,f"No fue posible cambiar el estado: {exc}")
    return redirect(request.POST.get("next") or reverse("elecciones:categorias_lista"))

@login_required
def categorias_copiar(request):
    form=CopiarCategoriasForm(request.POST or None)
    if request.method=="POST" and form.is_valid():
        creadas,omitidas=form.copiar()
        if creadas: messages.success(request,f"Se copiaron {len(creadas)} categoría(s) en estado borrador.")
        if omitidas: messages.warning(request,f"Se omitieron {len(omitidas)} categoría(s) porque ya existían en el destino.")
        return redirect("elecciones:categorias_lista")
    return render(request,"elecciones/categorias_copiar.html",{"form":form})

from django.db import transaction
from .forms import OpcionFormSet, VotacionForm


@login_required
def votaciones_lista(request):
    votaciones = Votacion.objects.select_related("categoria", "categoria__edicion", "tipo").annotate(total_opciones=Count("opciones"))
    q = request.GET.get("q", "").strip(); edicion = request.GET.get("edicion", "").strip(); estado = request.GET.get("estado", "").strip(); publicada = request.GET.get("publicada", "").strip()
    if q:
        votaciones = votaciones.filter(Q(nombre__icontains=q) | Q(categoria__nombre__icontains=q) | Q(tipo__nombre__icontains=q))
    if edicion:
        votaciones = votaciones.filter(categoria__edicion_id=edicion)
    if estado:
        votaciones = votaciones.filter(estado=estado)
    if publicada in {"si", "no"}:
        votaciones = votaciones.filter(publicada=publicada == "si")
    return render(request, "elecciones/votaciones_lista.html", {"votaciones": votaciones, "ediciones": Edicion.objects.all(), "estados": Votacion.Estado.choices, "filtros": {"q": q, "edicion": edicion, "estado": estado, "publicada": publicada}})


def _guardar_votacion(request, instancia=None):
    form = VotacionForm(request.POST or None, instance=instancia)
    formset = OpcionFormSet(request.POST or None, instance=instancia, prefix="opciones")
    if request.method == "POST" and form.is_valid() and formset.is_valid():
        with transaction.atomic():
            votacion = form.save()
            formset.instance = votacion
            formset.save()
        messages.success(request, f"La votación “{votacion.nombre}” fue guardada correctamente.")
        return redirect("elecciones:votaciones_lista")
    return render(request, "elecciones/votacion_form.html", {"form": form, "formset": formset, "titulo": "Editar votación" if instancia else "Crear votación", "votacion": instancia})


@login_required
def votacion_crear(request):
    return _guardar_votacion(request)


@login_required
def votacion_editar(request, pk):
    return _guardar_votacion(request, get_object_or_404(Votacion, pk=pk))


@login_required
def votacion_publicacion(request, pk, accion):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    votacion = get_object_or_404(Votacion.objects.select_related("categoria"), pk=pk)
    if accion not in {"publicar", "retirar"}:
        messages.error(request, "La acción solicitada no es válida.")
        return redirect("elecciones:votaciones_lista")
    if accion == "publicar":
        votacion.publicada = True
        if votacion.estado == Votacion.Estado.BORRADOR:
            votacion.estado = Votacion.Estado.PROGRAMADA
    else:
        votacion.publicada = False
    try:
        votacion.full_clean()
        votacion.save(update_fields=["publicada", "estado", "actualizado_en"])
        messages.success(request, "La votación fue publicada." if votacion.publicada else "La votación fue retirada del portal público.")
    except Exception as exc:
        messages.error(request, f"No fue posible completar la operación: {exc}")
    return redirect("elecciones:votaciones_lista")


@login_required
def votacion_estado(request, pk, estado):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    estados_validos = {valor for valor, etiqueta in Votacion.Estado.choices}
    votacion = get_object_or_404(Votacion, pk=pk)
    if estado not in estados_validos:
        messages.error(request, "El estado solicitado no es válido.")
    else:
        votacion.estado = estado
        if estado in {Votacion.Estado.BORRADOR, Votacion.Estado.CANCELADA}:
            votacion.publicada = False
        try:
            votacion.full_clean(); votacion.save(update_fields=["estado", "publicada", "actualizado_en"])
            messages.success(request, f"La votación ahora está {votacion.get_estado_display().lower()}.")
        except Exception as exc:
            messages.error(request, f"No fue posible cambiar el estado: {exc}")
    return redirect("elecciones:votaciones_lista")
